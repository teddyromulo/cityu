<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <link rel="stylesheet" href="https://use.fontawesome.com/releases/v5.8.0/css/all.css" integrity="sha384-Mmxa0mLqhmOeaE8vgOSbKacftZcsNYDjQzuCOm6D02luYSzBG8vpaOykv9lFQ51Y"
        crossorigin="anonymous">
    <title>CityU</title>
    <?php wp_head() ?>
    <link href="https://unpkg.com/aos@2.3.1/dist/aos.css" rel="stylesheet">
</head>

<body>
    <header>
        <div class="container">
            <div id="branding">
                    <div><img src="<?php echo get_theme_file_uri() ?>/img/logo.jpg" alt="CityU" align="middle" /></div>
                    <h1>Communication and Public Relations Office</h1>
            </div>
            <div class="search-form"><input type="text" placeholder="search" /><i class="fas fa-search" /></i><button>A+</button></div>
        </div>        
    </header>

    <!-- <div class="mobile-search-form">
                        <input type="text" placeholder="search" /><i class="fas fa-search" /></i>
                </div>  -->
    <section class="navigation">
    <div class="nav-container">
        <nav>
        <div class="nav-mobile"><a id="nav-toggle" href="#!"><span></span></a></div>
        <ul class="nav-list" >
            <li><a href="#!">Home</a></li>
            <li><a href="#!">About CPRO</a></li>
            <li><a href="#!">Branding</a>
                <ul class="nav-dropdown">
                    <li><a href="#!">CityU Brand</a></li>
                    <li><a href="#!">Corporate presentation</a></li>
                    <li><a href="#!">Corporate video</a></li>
                    <li><a href="#!">Souvenir</a></li>
                </ul>
            </li>
            <li><a href="#!">Services</a>
            <ul class="nav-dropdown">
                    <li><a href="#!">Event promotions</a></li>
                    <li><a href="#!">Via cap</a></li>
                    <li><a href="#!">Spotlight</a></li>
                    <li><a href="#!">Event LCD TV</a></li>
                    <li><a href="#!">Video Wall</a></li>
                    <li><a href="#!">Photography Services</a></li>
                </ul>
            </li>
            <li><a href="#!">University Communication</a>
                <ul class="nav-dropdown">
                    <li><a href="#!">Internal Communication</a></li>
                    <li><a href="#!">Linkage</a></li>
                    <li><a href="#!">Glossary</a></li>
                    <li><a href="#!">Multimedia</a></li>
                    <li><a href="#!">Campus broadcast system</a></li>
                    <li><a href="#!">CityU Album</a></li>
                </ul>
            </li>
            <li><a href="#!">Outreach</a>
                <ul class="nav-dropdown">
                    <li><a href="#!">Campus Visits</a></li>
                    <li><a href="#!">School Programmes</a></li>
      
                </ul>
            </li>
            <li><a href="#!">Media</a>
                <ul class="nav-dropdown">
                    <li><a href="#!">CityU in the news</a></li>
                    <li><a href="#!">CityU news center</a></li>
      
                </ul>
            </li>
            <li><a href="#!">Contact</a>
                <ul class="nav-dropdown">
                    <li><a href="#!">Campus Visits</a></li>
                    <li><a href="#!">School Programmes</a></li>
      
                </ul>
            </li>
        </ul>
        </nav>
    </div>
    </section>