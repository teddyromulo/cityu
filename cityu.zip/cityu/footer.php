

 <footer>
        <div class="container">
            <div class="footer-menu">
                        <div class="f-menu-home">
                            <h4><a href="#">Home</a></h4>
                        </div>
                        <div class="f-menu-about">
                            <h4><a href="#">About CPRO</a></h4>
                        </div>
                        <div class="f-menu-branding">
                            <h4><a href="#">Branding</a></h4>
                            <ul>
                                <li><a href="#">City brand</a></li>
                                <li><a href="#">Corporate presentation</a></li>
                                <li><a href="#">Corporate video</a></li>
                                <li><a href="#">Souvenirs</a></li>
                            </ul>
                        </div>
                        <div class="f-menu-services">
                            <h4><a href="#">Services</a></h4>
                            <ul>
                                <li><a href="#">Event promotions</a></li>
                                <li><a href="#">Via Cap</a></li>
                                <li><a href="#">Spotlight</a></li>
                                <li><a href="#">Event LCD TV</a></li>
                                <li><a href="#">Video Wall</a></li>
                                <li><a href="#">Photography Services</a></li>
                                <li><a href="#">Stock Photo</a></li>
                                <li><a href="#">Photographers</a></li>
                                <li><a href="#">Download Corp Videos</a></li>
                                <li><a href="#">Order Souvenirs</a></li>
                            
                            </ul>
                        </div>
                        <div class="f-menu-communication">
                            <h4><a href="#">University Communication</a></h4>
                            <ul>
                                <li><a href="#">Internal communication</a></li>
                                <li><a href="#">Linkage</a></li>
                                <li><a href="#">Glosarry</a></li>
                                <li><a href="#">Multimedia</a></li>
                                <li><a href="#">Campus Broadcast System</a></li>
                                <li><a href="#">CityU Album</a></li>
                                <li><a href="#">Videos</a></li>
                                <li><a href="#">Publications</a></li>
                                <li><a href="#">Annual Report</a></li>
                                <li><a href="#">CityU at a glance</a></li>
                                <li><a href="#">CityU Today</a></li>
                                <li><a href="#">CityU Update</a></li>
                                <li><a href="#">Corporate Folder</a></li>
                                <li><a href="#">Newscentre</a></li>
                                <li><a href="#">Social Media</a></li>
                            
                            </ul>
                        </div>
                        <div class="f-menu-outreach">
                            <h4><a href="#">Outreach</a></h4>

                                <ul>
                                    <li><a href="#">Campus Visits</a></li>
                                    <li><a href="#">School Programmes</a></li>
                                </ul>
                            
                        </div>
                        <div class="f-menu-media">
                            <h4>
                                <a href="#">Media</a>
                            </h4>
                            <ul>
                                <li><a href="#">CityU in the new</a></li>
                                <li><a href="#">CityU Newscentre</a></li>
                                <li><a href="#">Find an Expert</a></li>
                            </ul>
                        </div>
                        <div class="f-menu-contact">
                            <h4>
                                <a href="#">Contact</a>
                            </h4>
                        </div>
            </div>
            <div id="footer-div"></div>
            <div class="footer-bottom">
                <div class="footer-menu2">
                    <ul>
                        <li><a href="#">Privacy Policy</a></li>
                        <li><a href="#">Copyright</a></li>
                        <li><a href="#">Disclaimer</a></li>
                        <li><a href="#">Contact us</a></li>
                        <li><a href="#">Download PDF Reader</a></li>                        
                    </ul>
                    <p>2017 City University of Hong Kong. All Rights Reserved.</p>
                </div>
                <div class="cityu-logo2">
                    <img src="<?php echo get_theme_file_uri() ?>/img/logo2.jpg" />
                </div>    
            </div>
        </div>
    </footer>
    <?php wp_footer(); ?>
    <script src="https://ajax.googleapis.com/ajax/libs/jquery/1.11.0/jquery.min.js"></script>
    <script src="https://unpkg.com/tilt.js@1.1.21/dest/tilt.jquery.min.js"></script>
    <script type="text/javascript" src="<?php echo get_theme_file_uri() ?>/js/slick.js"></script>
        <script type="text/javascript" src="<?php echo get_theme_file_uri() ?>/js/slick-scripts.js"></script>
        <script type="text/javascript" src="<?php echo get_theme_file_uri() ?>/js/cityu.js"></script>
        <script src="<?php echo get_theme_file_uri() ?>/js/fb-slider.js"></script>
        <script src="https://unpkg.com/aos@2.3.1/dist/aos.js"></script>
        <script>
        jQuery(function($) {$('.fb-slider').sss();});
        AOS.init();
        </script>


</body>
</html>
