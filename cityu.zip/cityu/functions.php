<?php

//adding css and js files

function _setup(){
    wp_enqueue_style('font-awesome', 'https://use.fontawesome.com/releases/v5.8.0/css/all.css');
    wp_enqueue_style("style", get_stylesheet_uri(), NULL, microtime(), all);
    wp_enqueue_style ('slick-style', get_template_directory_uri().'/css/slick.css');
    wp_enqueue_style ('fb-style', get_template_directory_uri().'/css/fb-slider.css');
    wp_enqueue_style ('navbar-style', get_template_directory_uri().'/css/navbar.css');

    wp_enqueue_script( 'navbar-script', get_template_directory_uri() . '/js/navbar.js', array ( 'jquery' ), microtime(), true);

}

add_action('wp_enqueue_scripts', '_setup');

//adding theme support

function _init(){
    add_theme_support('post-thumbnails');
    add_theme_support('title-tag'); // title tag
    add_theme_support('html5',
        array('comment-list', 'comment-form', 'search-form')
        ); 
}

add_action('after_setup_theme', _init);

// add post type for slides

function _custom_post_type(){
    register_post_type('slides',
        array(
            'rewrite' => array('slug' => 'slides'),
            'labels' => array(
                'name' => 'Slides',
                'singular_name' => 'Project',
                'add_new_item' => 'Add New Slide',
                'edit_item' => 'Edit Project'
                ),
            'menu-icon' => 'dashicons-images-alt2',
            'public' => true,
            'has_archive' => true,
            'supports' => array(
                        'title', 'thumbnail', 'editor', 'excerpt', 'comments'
                        

            )
        )
    );
}

add_action('init', '_custom_post_type');

//

register_nav_menus( array( 
    'primary' => 'Primary menu', 
    'footer' => 'Footer menu' 
  ) );