<?php get_header();?>
<section id="slide">
            
        <div class="content">
            
            <div class="slider single-item">
                <span id="nav-div"></span>
            
                <?php
                    $query = new WP_Query();
                    $all_prods = array(
                        'posts_per_page' => -1,
                        'post_type'      => 'slides',
                    );
                    $query = new WP_Query($all_prods);

                    while ($query->have_posts()) {
                        $query->the_post();
                        $post_id = get_the_ID();
                        $post_title = get_the_title();
                         $image_url = wp_get_attachment_image_src( get_post_thumbnail_id($post_id), "" );
                         $image_url = $image_url[0];                                      
                    ?>  

                <div class="s-item" style="background: linear-gradient(rgba(0,0,0,0.3), rgba(0,0,0,0.2)), url(<?php echo $image_url ?>) center center;"><p><span><?php echo $post_title ?></span></p></div>

                <?php
                    }
                    wp_reset_query(); //resetting the page query
                ?>
              
            </div>
        </div>
	</section>
    <section id="about-cpro">
 
        <div class="container2" data-aos="fade-up" data-aos-delay="100" data-aos-duration="2000">
        <?php
        $query = new WP_Query();
        $homepage = array(
            'p' => 7,
            'post_type'      => 'any',
        );
        $query = new WP_Query($homepage);

        while ( have_posts() ) : the_post(); ?> <!--Because the_content() works only inside a WP Loop -->
            <h3>About CPRO</h3>
            <p><?php echo str_replace( '<p></p>', '', the_content() ); ?></p>
        </div>        
    </section>
    <section id="about-cityu">
        <div class="container2" data-aos="fade-up" data-aos-delay="100" data-aos-duration="2000">
            <h3><?php echo the_field( 'section_title', get_the_ID()); ?>  </h3>
            <div class="brand-wrapper">    
                <div class="brand-item" data-aos="flip-right" data-aos-delay="50" data-aos-duration="1000">
                    <img src="<?php echo the_field( 'icon1', get_the_ID()); ?>" alt="Brand Pillars" />
                    <h4><?php echo the_field( 'title1', get_the_ID()); ?></h4>
                    <p><?php echo the_field( 'desc1', get_the_ID()); ?></p>
                </div>
                <div class="brand-item" data-aos="flip-right" data-aos-delay="75" data-aos-duration="1500">
                    <img src="<?php echo the_field( 'icon2', get_the_ID()); ?>" alt="Brand Personality" />
                    <h4><?php echo the_field( 'title2', get_the_ID()); ?></h4>
                    <p><?php echo the_field( 'desc2', get_the_ID()); ?></p>
                </div>
                <div class="brand-item" data-aos="flip-right" data-aos-delay="100" data-aos-duration="2000">
                    <img src="<?php echo the_field( 'icon3', get_the_ID()); ?>" alt="Brand Position" />
                    <h4><?php echo the_field( 'title3', get_the_ID()); ?></h4>
                    <p><?php echo the_field( 'desc3', get_the_ID()); ?></p>
                </div>
            </div> 
            <button class="button" /><span>Learn More</span></button>   
        </div>
    </div>
    </section>
    <?php
        endwhile; //resetting the page loop
        wp_reset_query(); //resetting the page query
        ?>
    <section id="facebook">
        <div class="container">     
                <div class="fb-wrapper">  
                        <div class="fb-button"><a href="#">CityU Facebook</a></div> 
                        <div class="fb-slider">
                                <div class="just_text"><div class="s-image"><img src="<?php echo get_theme_file_uri() ?>/img/thumb.jpg" /></div><div class=s-text>Morbi felis mauris, consequat id eros eget, pharetra lacinia ligula. Morbi vel placerat nisi. </div></div>
                                <div class="just_text"><div class="s-image"><img src="<?php echo get_theme_file_uri() ?>/img/thumb2.jpg" /></div><div class=s-text>Praesent tempus leo sit amet nulla aliquet sodales. Nulla vel felis justo. Pellentesque et mattis justo,</div></div>
                        </div>
                </div>
        </div> 
    </section>  

    <section>
        <div id="services">
            <div class="container" data-aos="fade-up" data-aos-delay="100" data-aos-duration="2000">
            <h3>Services</h3>
            <p>Proin quis vehicula nunc. Integer vitae massa ut libero tristique bibendum a vel sem. Integer non volutpat magna, posuere ultricies urna. Sed sed ex at magna molestie porta.
                Praesent varius enim ut quam tempus. </p>
                <div class="news-wrapper">
                   <div class="news-item news1-left" data-tilt data-tilt-glare="true" data-tilt-scale="1" style="background: linear-gradient(rgba(0,0,0,0.5), rgba(0,0,0,0.4)), url(<?php echo get_theme_file_uri() ?>/img/news1-left.jpg) center center;">
                       <a href="#">                       
                        <i class="fas fa-video" /></i>
                        <h4>CORPORATE VIDEOS</h4>
                       </a> 
                   </div> 
                   <div class="news-item news1-right" data-tilt data-tilt-glare="true" data-tilt-scale="1" style="background: linear-gradient(rgba(0,0,0,0.5), rgba(0,0,0,0.4)), url(<?php echo get_theme_file_uri() ?>/img/news1-right.jpg) center center;">
                        <a href="#"> 
                        <i class="fas fa-building" /></i>
                        <h4>EVENT PROMOTIONS</h4>
                        </a>
                   </div> 
                   <div class="news-item news2-left" data-tilt data-tilt-glare="true" data-tilt-scale="1" style="background: linear-gradient(rgba(0,0,0,0.5), rgba(0,0,0,0.4)), url(<?php echo get_theme_file_uri() ?>/img/news2-left.jpg) center center;">
                        <a href="#"> 
                        <i class="fas fa-gift" /></i>
                        <h4>CITYU SOUVENIRS</h4>
                        </a>
                   </div>
                   <div class="news-item news2-right" data-tilt data-tilt-glare="true" data-tilt-scale="1" style="background: linear-gradient(rgba(0,0,0,0.5), rgba(0,0,0,0.4)), url(<?php echo get_theme_file_uri() ?>/img/news2-right.jpg) center center;">
                        <a href="#"> 
                        <i class="fas fa-camera" /></i>
                        <h4>PHOTOGRAPHY SERVICES</h4>
                        </a>
                   </div> 
                </div>
            </div>    
        </div>
    </section>

    <section>
        <div id="latest-news" data-aos="fade-up" data-aos-delay="100" data-aos-duration="2000">
            <h3>Latest News</h3>
            <p>Proin quis vehicula nunc. Integer vitae massa ut libero tristique bibendum a vel sem. Integer non volutpat magna, posuere ultricies urna. Sed sed ex at magna molestie porta.
                Praesent varius enim ut quam tempus. </p>
            <div class="latest-news-wrapper">
                   <div class="latest-news-item latest-news-item1" style="background: linear-gradient(rgba(0,0,0,0.3), rgba(0,0,0,0.2)), url(<?php echo get_theme_file_uri() ?>/img/latest_news_1.jpg) center center;">
                       <h4>Integer non volutpat magna, posuere ultricies urna</h4>
                       <p>03 March 2019</p>
                   </div>
                    <div class="latest-news-item latest-news-item2" style="background: linear-gradient(rgba(0,0,0,0.3), rgba(0,0,0,0.2)), url(<?php echo get_theme_file_uri() ?>/img/latest_news_2.jpg) center center;">
                        <h4>Integer non volutpat magna, posuere ultricies urna</h4>
                        <p>03 March 2019</p>
                    </div>
                    <div class="latest-news-item latest-news-item3" style="background: linear-gradient(rgba(0,0,0,0.3), rgba(0,0,0,0.2)), url(<?php echo get_theme_file_uri() ?>/img/latest_news_3.jpg) center center;">
                        <h4>Integer non volutpat magna, posuere ultricies urna</h4>
                       <p>03 March 2019</p>
                    </div>
            </div>
 
        </div>
    </section>
    <section>
        <div id="contact-us" style="background:linear-gradient(rgb(208,0,93,0.7), rgb(208,0,93,0.7)), url(<?php echo get_theme_file_uri() ?>/img/contact_us.jpg) center center;" >
            <div class="contact-us-item">
                <h3>Questions on Public Relations & Communication matters?</h3>
            <a href="#" class="button2">Contact Us</a>
            </div>
        </div>
    </section>
<?php get_footer();?>