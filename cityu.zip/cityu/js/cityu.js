const mobileMenu = document.getElementById("mobile-menu");
const menuIcon = document.getElementById("mobile-menu-icon");

menuIcon.addEventListener('click', function(){
    if (mobileMenu.style.opacity == "1"){
        mobileMenu.style.opacity = 0;
        mobileMenu.style.pointerEvents = 'none';
    }else{
        mobileMenu.style.opacity ='1';
        mobileMenu.style.pointerEvents = 'auto';
    }
});